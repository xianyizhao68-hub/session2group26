import React from "react";

const styles = {
  healthy: "bg-green-100 text-green-700 border-green-200",
  mild_issues: "bg-yellow-100 text-yellow-700 border-yellow-200",
  needs_attention: "bg-orange-100 text-orange-700 border-orange-200",
  critical: "bg-red-100 text-red-700 border-red-200",
};

const labels = {
  healthy: "Healthy",
  mild_issues: "Mild Issues",
  needs_attention: "Needs Attention",
  critical: "Critical",
};

export default function HealthBadge({ status }) {
  const safeStatus = status || "healthy";

  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium ${
        styles[safeStatus] || styles.healthy
      }`}
    >
      {labels[safeStatus] || "Healthy"}
    </span>
  );
}
