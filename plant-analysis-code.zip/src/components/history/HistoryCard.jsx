import React from "react";
import { format } from "date-fns";
import { Leaf, ChevronRight } from "lucide-react";
import HealthBadge from "../results/HealthBadge";

export default function HistoryCard({ analysis, onClick }) {
  return (
    <div
      onClick={onClick}
      className="group bg-card rounded-2xl border border-border/50 overflow-hidden hover:border-primary/20 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 cursor-pointer"
    >
      <div className="flex flex-col sm:flex-row">
        <div className="sm:w-32 h-32 sm:h-auto shrink-0">
          {analysis.plant_image_url ? (
            <img
              src={analysis.plant_image_url}
              alt={analysis.plant_name || "Plant"}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-muted flex items-center justify-center">
              <Leaf className="w-6 h-6 text-muted-foreground" />
            </div>
          )}
        </div>

        <div className="flex-1 p-4 flex flex-col justify-between gap-2">
          <div>
            <div className="flex items-center justify-between gap-2">
              <h3 className="font-semibold text-sm truncate">
                {analysis.plant_name || "Plant Analysis"}
              </h3>

              <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary shrink-0 transition-colors" />
            </div>

            {analysis.summary && (
              <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                {analysis.summary}
              </p>
            )}
          </div>

          <div className="flex items-center justify-between gap-2">
            <HealthBadge status={analysis.health_status} />

            <span className="text-[11px] text-muted-foreground">
              {analysis.created_date
                ? format(new Date(analysis.created_date), "MMM d, yyyy")
                : ""}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
