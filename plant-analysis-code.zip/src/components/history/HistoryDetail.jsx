import React from "react";
import { X, Thermometer, Droplets, FlaskConical, AlertTriangle } from "lucide-react";
import HealthBadge from "../results/HealthBadge";

export default function HistoryDetail({ analysis, onClose }) {
  if (!analysis) return null;

  const ideal = analysis.ideal_conditions || {};

  return (
    <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4">
      <div className="bg-background w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-3xl shadow-xl border">
        <div className="flex items-center justify-between p-5 border-b">
          <div>
            <h2 className="text-xl font-semibold">
              {analysis.plant_name || "Plant Analysis"}
            </h2>
            <p className="text-sm text-muted-foreground">
              Detailed plant health report
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-muted transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {analysis.plant_image_url && (
          <img
            src={analysis.plant_image_url}
            alt={analysis.plant_name || "Plant"}
            className="w-full h-64 object-cover"
          />
        )}

        <div className="p-5 space-y-6">
          <div className="flex items-center gap-3">
            <HealthBadge status={analysis.health_status} />

            {analysis.urgency && (
              <span className="inline-flex items-center gap-1 text-sm text-muted-foreground">
                <AlertTriangle className="w-4 h-4" />
                Urgency: {analysis.urgency}
              </span>
            )}
          </div>

          {analysis.summary && (
            <div>
              <h3 className="font-semibold mb-2">Summary</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {analysis.summary}
              </p>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <InfoCard
              icon={<Thermometer className="w-5 h-5" />}
              label="Temperature"
              value={
                analysis.temperature !== undefined && analysis.temperature !== null
                  ? `${analysis.temperature}°C`
                  : "N/A"
              }
            />

            <InfoCard
              icon={<Droplets className="w-5 h-5" />}
              label="Humidity"
              value={
                analysis.humidity !== undefined && analysis.humidity !== null
                  ? `${analysis.humidity}%`
                  : "N/A"
              }
            />

            <InfoCard
              icon={<FlaskConical className="w-5 h-5" />}
              label="Soil pH"
              value={
                analysis.soil_ph !== undefined && analysis.soil_ph !== null
                  ? analysis.soil_ph
                  : "N/A"
              }
            />
          </div>

          {analysis.problems_detected?.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2">Problems Detected</h3>
              <ul className="space-y-2">
                {analysis.problems_detected.map((problem, index) => (
                  <li
                    key={index}
                    className="text-sm bg-muted rounded-xl px-3 py-2"
                  >
                    {problem}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {analysis.care_suggestions?.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2">Care Suggestions</h3>
              <div className="space-y-3">
                {analysis.care_suggestions.map((item, index) => (
                  <div key={index} className="border rounded-xl p-3">
                    <p className="text-sm font-medium">
                      {item.category || "Care"}
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      {item.suggestion}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div>
            <h3 className="font-semibold mb-2">Ideal Conditions</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <InfoCard
                label="Temperature"
                value={
                  ideal.temperature_min !== undefined && ideal.temperature_min !== null
                    ? `${ideal.temperature_min}°C - ${ideal.temperature_max}°C`
                    : "N/A"
                }
              />

              <InfoCard
                label="Humidity"
                value={
                  ideal.humidity_min !== undefined && ideal.humidity_min !== null
                    ? `${ideal.humidity_min}% - ${ideal.humidity_max}%`
                    : "N/A"
                }
              />

              <InfoCard
                label="Soil pH"
                value={
                  ideal.soil_ph_min !== undefined && ideal.soil_ph_min !== null
                    ? `${ideal.soil_ph_min} - ${ideal.soil_ph_max}`
                    : "N/A"
                }
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoCard({ icon, label, value }) {
  return (
    <div className="bg-muted rounded-2xl p-4">
      <div className="flex items-center gap-2 text-muted-foreground mb-1">
        {icon}
        <span className="text-xs">{label}</span>
      </div>
      <p className="font-semibold">{value}</p>
    </div>
  );
}
