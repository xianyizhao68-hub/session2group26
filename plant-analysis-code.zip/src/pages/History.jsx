import React, { useEffect, useState } from "react";
import { Leaf, Loader2 } from "lucide-react";
import { PlantAnalysis } from "@/entities/PlantAnalysis";
import HistoryCard from "@/components/history/HistoryCard";
import HistoryDetail from "@/components/history/HistoryDetail";

export default function History() {
  const [analyses, setAnalyses] = useState([]);
  const [selectedAnalysis, setSelectedAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  async function loadHistory() {
    try {
      setLoading(true);
      const data = await PlantAnalysis.list("-created_date");
      setAnalyses(data || []);
    } catch (error) {
      console.error("Failed to load history:", error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-background px-4 py-6">
      <div className="max-w-5xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Analysis History</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Review your previous plant health analyses.
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : analyses.length === 0 ? (
          <div className="border rounded-3xl p-10 text-center bg-card">
            <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Leaf className="w-7 h-7 text-muted-foreground" />
            </div>
            <h2 className="font-semibold text-lg">No analysis yet</h2>
            <p className="text-sm text-muted-foreground mt-2">
              Analyze your first plant to see history here.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {analyses.map((analysis) => (
              <HistoryCard
                key={analysis.id}
                analysis={analysis}
                onClick={() => setSelectedAnalysis(analysis)}
              />
            ))}
          </div>
        )}
      </div>

      <HistoryDetail
        analysis={selectedAnalysis}
        onClose={() => setSelectedAnalysis(null)}
      />
    </div>
  );
}
