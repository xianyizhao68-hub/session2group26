import React, { useState } from "react";
import { Upload, Loader2, Leaf } from "lucide-react";
import { PlantAnalysis } from "@/entities/PlantAnalysis";
import { UploadFile, InvokeLLM } from "@/integrations/Core";
import HealthBadge from "@/components/results/HealthBadge";

const responseSchema = {
  type: "object",
  properties: {
    health_status: {
      type: "string",
      enum: ["healthy", "mild_issues", "needs_attention", "critical"],
    },
    problems_detected: {
      type: "array",
      items: {
        type: "string",
      },
    },
    care_suggestions: {
      type: "array",
      items: {
        type: "object",
        properties: {
          category: {
            type: "string",
          },
          suggestion: {
            type: "string",
          },
        },
      },
    },
    urgency: {
      type: "string",
      enum: ["low", "medium", "high"],
    },
    plant_name: {
      type: "string",
    },
    summary: {
      type: "string",
    },
    ideal_conditions: {
      type: "object",
      properties: {
        temperature_min: {
          type: "number",
        },
        temperature_max: {
          type: "number",
        },
        humidity_min: {
          type: "number",
        },
        humidity_max: {
          type: "number",
        },
        soil_ph_min: {
          type: "number",
        },
        soil_ph_max: {
          type: "number",
        },
      },
    },
  },
};

export default function Analyze() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState("");
  const [temperature, setTemperature] = useState("");
  const [humidity, setHumidity] = useState("");
  const [soilPh, setSoilPh] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  function handleFileChange(event) {
    const selectedFile = event.target.files?.[0];

    if (!selectedFile) return;

    setFile(selectedFile);
    setPreview(URL.createObjectURL(selectedFile));
    setResult(null);
  }

  async function handleAnalyze() {
    if (!file) {
      alert("Please upload a plant image first.");
      return;
    }

    try {
      setLoading(true);

      const uploadResult = await UploadFile({
        file,
      });

      const imageUrl = uploadResult.file_url;

      const aiResult = await InvokeLLM({
        prompt: `
You are a professional plant health assistant.

Analyze the uploaded plant image and environmental data.

Environmental data:
- Temperature: ${temperature || "unknown"} Celsius
- Humidity: ${humidity || "unknown"}%
- Soil pH: ${soilPh || "unknown"}

Return:
1. Plant name if identifiable
2. Health status
3. Problems detected
4. Care suggestions
5. Urgency
6. Short summary
7. Ideal growing conditions

Be practical and concise.
        `,
        file_urls: [imageUrl],
        response_json_schema: responseSchema,
      });

      const savedRecord = await PlantAnalysis.create({
        plant_image_url: imageUrl,
        temperature: temperature ? Number(temperature) : null,
        humidity: humidity ? Number(humidity) : null,
        soil_ph: soilPh ? Number(soilPh) : null,
        health_status: aiResult.health_status,
        problems_detected: aiResult.problems_detected || [],
        care_suggestions: aiResult.care_suggestions || [],
        urgency: aiResult.urgency,
        plant_name: aiResult.plant_name,
        summary: aiResult.summary,
        ideal_conditions: aiResult.ideal_conditions || {},
      });

      setResult(savedRecord);
    } catch (error) {
      console.error("Analyze failed:", error);
      alert("Analysis failed. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-background px-4 py-6">
      <div className="max-w-5xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Plant Analysis</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Upload a plant photo and get AI-powered care suggestions.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-card border rounded-3xl p-5 space-y-5">
            <div>
              <label className="block text-sm font-medium mb-2">
                Plant Image
              </label>

              <label className="border-2 border-dashed rounded-3xl h-64 flex flex-col items-center justify-center cursor-pointer hover:bg-muted/50 transition overflow-hidden">
                {preview ? (
                  <img
                    src={preview}
                    alt="Plant preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center">
                    <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">
                      Click to upload plant image
                    </p>
                  </div>
                )}

                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Input
                label="Temperature °C"
                value={temperature}
                onChange={setTemperature}
                placeholder="25"
              />

              <Input
                label="Humidity %"
                value={humidity}
                onChange={setHumidity}
                placeholder="60"
              />

              <Input
                label="Soil pH"
                value={soilPh}
                onChange={setSoilPh}
                placeholder="6.5"
              />
            </div>

            <button
              onClick={handleAnalyze}
              disabled={loading}
              className="w-full rounded-2xl bg-primary text-primary-foreground py-3 font-medium hover:opacity-90 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Leaf className="w-4 h-4" />
                  Analyze Plant
                </>
              )}
            </button>
          </div>

          <div className="bg-card border rounded-3xl p-5">
            {!result ? (
              <div className="h-full min-h-64 flex flex-col items-center justify-center text-center">
                <Leaf className="w-10 h-10 text-muted-foreground mb-3" />
                <h2 className="font-semibold">No result yet</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Upload a plant image and start analysis.
                </p>
              </div>
            ) : (
              <ResultPanel result={result} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Input({ label, value, onChange, placeholder }) {
  return (
    <div>
      <label className="block text-xs font-medium mb-1">{label}</label>
      <input
        type="number"
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="w-full rounded-xl border bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/30"
      />
    </div>
  );
}

function ResultPanel({ result }) {
  return (
    <div className="space-y-5">
      <div>
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-xl font-semibold">
            {result.plant_name || "Plant Analysis"}
          </h2>
          <HealthBadge status={result.health_status} />
        </div>

        {result.summary && (
          <p className="text-sm text-muted-foreground mt-2">
            {result.summary}
          </p>
        )}
      </div>

      {result.problems_detected?.length > 0 && (
        <div>
          <h3 className="font-semibold mb-2">Problems Detected</h3>
          <ul className="space-y-2">
            {result.problems_detected.map((problem, index) => (
              <li key={index} className="text-sm bg-muted rounded-xl p-3">
                {problem}
              </li>
            ))}
          </ul>
        </div>
      )}

      {result.care_suggestions?.length > 0 && (
        <div>
          <h3 className="font-semibold mb-2">Care Suggestions</h3>
          <div className="space-y-3">
            {result.care_suggestions.map((item, index) => (
              <div key={index} className="border rounded-xl p-3">
                <p className="text-sm font-medium">
                  {item.category || "Care"}
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  {item.suggestion}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
